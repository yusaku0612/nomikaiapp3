SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- �����̃e�[�u�����폜
IF OBJECT_ID('dbo.Payments', 'U') IS NOT NULL
    DROP TABLE dbo.Payments;
GO
IF OBJECT_ID('dbo.Events', 'U') IS NOT NULL
    DROP TABLE dbo.Events;
GO
IF OBJECT_ID('dbo.Participants', 'U') IS NOT NULL
    DROP TABLE dbo.Participants;
GO

-- Participants �e�[�u�����쐬
CREATE TABLE [dbo].[Participants](
    [ParticipantID] [int] IDENTITY(1,1) NOT NULL,
      -- ���O�̗��ǉ�
    CONSTRAINT [PK_Participants] PRIMARY KEY CLUSTERED 
    (
        [ParticipantID] ASC
    ) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) 
    ON [PRIMARY]
);
GO

-- Events �e�[�u�����쐬
CREATE TABLE [dbo].[Events](
    [EventID] [int] IDENTITY(1,1) NOT NULL,
      -- �C�x���g���̗��ǉ�
    [EventDate] [datetime] NOT NULL,
    [TotalAmount] [decimal](18, 2) NOT NULL,
    CONSTRAINT [PK_Events] PRIMARY KEY CLUSTERED 
    (
        [EventID] ASC
    ) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) 
    ON [PRIMARY]
);
GO

-- Payments �e�[�u�����쐬
CREATE TABLE [dbo].[Payments](
    [PaymentID] [int] IDENTITY(1,1) NOT NULL,
    [EventID] [int] NOT NULL,
    [ParticipantID] [int] NOT NULL,
    [AmountPaid] [decimal](18, 2) NOT NULL,
    CONSTRAINT [PK_Payments] PRIMARY KEY CLUSTERED 
    (
        [PaymentID] ASC
    ) WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) 
    ON [PRIMARY]
);
GO

-- �O���L�[�����ǉ�
ALTER TABLE [dbo].[Payments]  WITH CHECK ADD  CONSTRAINT [FK_Payments_Events] FOREIGN KEY([EventID])
REFERENCES [dbo].[Events] ([EventID]);
GO

ALTER TABLE [dbo].[Payments] CHECK CONSTRAINT [FK_Payments_Events];
GO

ALTER TABLE [dbo].[Payments]  WITH CHECK ADD  CONSTRAINT [FK_Payments_Participants] FOREIGN KEY([ParticipantID])
REFERENCES [dbo].[Participants] ([ParticipantID]);
GO

ALTER TABLE [dbo].[Payments] CHECK CONSTRAINT [FK_Payments_Participants];
GO
